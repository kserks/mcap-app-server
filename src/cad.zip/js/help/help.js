var helpData = [
{
        "Title" : "Line",
        "Type" : "Command",
        "Shortcut" : "L",
		"Description" : "Draws a line made from two point"
    },
     {
        "Title" : "Circle",
        "Type" : "Command",
        "Shortcut" : "C",
		"Description" : "Draws a Circle made from two point"
    }

]
